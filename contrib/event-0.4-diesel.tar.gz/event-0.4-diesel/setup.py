#!/usr/bin/env python
#
# $Id: setup.py 49 2008-05-11 03:06:12Z dugsong $

### NOTE ###
# The diesel project has modified this file to:
#  a.) Use setuptools
#  b.) build the .c file fresh, requiring pyrex

import sys

try:
	import Pyrex
except ImportError:
	sys.stdout.write("Pyrex is required to install pyevent.\n")
	sys.stdout.write(" -> Run `easy_install -UZ Pyrex`\n")
	raise SystemExit(1)

from setuptools import setup, Extension

event = Extension('event', ['event.pyx'], libraries=['event'])

setup(name='event',
      version='0.4-diesel',
      author='Dug Song',
      author_email='dugsong@monkey.org',
      url='http://monkey.org/~dugsong/pyevent/',
      description='event library',
      long_description="""This module provides a mechanism to execute a function when a specific event on a file handle, file descriptor, or signal occurs, or after a given time has passed.""",
      license='BSD',
      download_url='http://monkey.org/~dugsong/pyevent/',
      ext_modules = [ event ])
